package Controlador;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.Alumno;
import servicios.AlumnoServices;

@RestController
@RequestMapping("/alumnos")
public class AlumnoController {
	
	@Autowired
    private AlumnoServices alumnoServices;

    @GetMapping
    public List<Alumno> getAll() {
        return alumnoServices.getAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> read(@PathVariable Long id) {
        return alumnoServices.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Alumno alumno) {
        Long id = alumnoServices.create(alumno);
        URI uri = URI.create("/alumnos/" + id);
        return ResponseEntity.created(uri).build();
    }

    @PutMapping
    public ResponseEntity<?> update(@RequestBody Alumno alumno) {
        try {
            alumnoServices.update(alumno);
            return ResponseEntity.noContent().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            alumnoServices.delete(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
