package servicios;

import java.util.List;
import java.util.Optional;

import model.Alumno;

public interface AlumnoServices {
	Long create(Alumno alumno);
    Optional<Alumno> read(Long id);
    void update(Alumno alumno);
    void delete(Long id);
    List<Alumno> getAll();
    
}
