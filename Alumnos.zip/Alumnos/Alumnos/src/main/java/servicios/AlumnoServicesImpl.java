package servicios;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import model.Alumno;

public class AlumnoServicesImpl implements AlumnoServices {
	private final TreeMap<Long, Alumno> alumnos = new TreeMap<>();
	private Long IDActual = 1L;

	public AlumnoServicesImpl() {
		alumnos.put(IDActual, new Alumno(IDActual++, "Guillem", 30));
		alumnos.put(IDActual, new Alumno(IDActual++, "Wary", 23));
		alumnos.put(IDActual, new Alumno(IDActual++, "María", 19));
	}

	@Override
	public Long create(Alumno alumno) {
		alumno.setId(IDActual++);
		alumnos.put(alumno.getId(), alumno);
		return alumno.getId();
	}

	@Override
	public Optional<Alumno> read(Long id) {
		return Optional.ofNullable(alumnos.get(id));
	}

	@Override
	public void update(Alumno alumno) {
		if (!alumnos.containsKey(alumno.getId())) {
			throw new IllegalStateException("El alumno no existe.");
		}
		alumnos.put(alumno.getId(), alumno);

	}

	@Override
	public void delete(Long id) {
		if (!alumnos.containsKey(id)) {
			throw new IllegalStateException("El alumno no existe.");
		}
		alumnos.remove(id);

	}

	@Override
	public List<Alumno> getAll() {
		return new ArrayList<>(alumnos.values());
	}

}
